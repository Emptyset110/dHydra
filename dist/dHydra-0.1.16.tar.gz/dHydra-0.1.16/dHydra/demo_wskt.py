# -*- coding: utf8 -*-
import dHydra
import sinaFinance

sina = sinaFinance.SinaFinance()
sina.wskt_token()