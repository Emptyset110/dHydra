__version__ = '0.1.0'
__author__ = 'Wen Gu'
try:
	from dHydra.dHydra import Stock
	from dHydra.sinaFinance import SinaFinance
except:
	from dHydra import Stock
	from sinaFinance import SinaFinance

